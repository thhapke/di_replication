# table to csv stream - s.d051079.OneDrive - SAP SE.GitHub.sdi_utils.deprecated.table_csv (Version: 0.0.1)

Converts table to csv stream.

## Inport

* **data** (Type: message.table) Input message with table

## outports

* **log** (Type: string) Logging data
* **csv** (Type: message) Output data as csv

## Config

* **debug_mode** - Debug mode (Type: boolean) Sending debug level information to log port
* **drop_columns** - Drop Columns (Type: string) List of columns to drop.


# Tags
sdi_utils : 

